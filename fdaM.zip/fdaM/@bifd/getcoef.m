function coef = getcoef(bifd)
coef = bifd.coef;