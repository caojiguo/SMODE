function [thetaHatMean,thetaHatBias,thetaHatStd,thetaHatRmse,thetaHatMse] = ...
              InferSum(thetaHatMat,thetaTru);

nSimu = size(thetaHatMat,2);
thetaHatMean = mean(thetaHatMat')';
thetaHatBias = thetaHatMean - thetaTru;
thetaHatStd = std(thetaHatMat')';
thetaHatRmse = sqrt(thetaHatBias.^2+thetaHatStd.^2);
thetaHatMse = mean(((thetaHatMat-thetaTru*ones(1,nSimu)).^2)'); 
